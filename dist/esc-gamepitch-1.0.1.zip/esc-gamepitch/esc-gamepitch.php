<?php
/**
 * Plugin Name: ESC GamePitch
 * Plugin URI:        https://github.com/hannesdev63/esc-gamepitch
 * Description: Renders HockeyData GamePitch widgets via shortcode using the HockeyData JavaScript API.
 * Version: 1.0.1
 * Author: hannesdev63
 * Requires at least: 5.9
 * Requires PHP:      7.4
 * Author:            hannesdev63
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 */

if (! defined('ABSPATH')) {
    exit;
}

final class ESC_GamePitch_Plugin
{
    const OPTION_KEY = 'esc_gamepitch_settings';
    const VERSION    = '1.0.1';

    private static $instance = null;

    private function __construct()
    {
        add_action('init', array($this, 'register_block'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_notices', array($this, 'render_admin_notice'));
        add_action('admin_menu', array($this, 'register_settings_page'));
        add_action('wp_enqueue_scripts', array($this, 'register_assets'));
        add_action('enqueue_block_editor_assets', array($this, 'register_block_editor_assets'));
        add_action('admin_post_esc_gamepitch_install_template', array($this, 'handle_install_template'));

        add_shortcode('esc_gamepitch', array($this, 'render_shortcode'));
        add_shortcode('esc_schedule', array($this, 'render_schedule_shortcode'));
        add_shortcode('esc_standings', array($this, 'render_standings_shortcode'));
        add_shortcode('esc_game_livebox', array($this, 'render_game_livebox_shortcode'));
        add_shortcode('esc_divisionpicker', array($this, 'render_divisionpicker_shortcode'));
        add_shortcode('esc_gameticker', array($this, 'render_gameticker_shortcode'));
        add_shortcode('esc_gameticker_current', array($this, 'render_gameticker_current_shortcode'));
        add_shortcode('esc_gameslider', array($this, 'render_gameslider_shortcode'));
        add_shortcode('esc_livegames', array($this, 'render_livegames_shortcode'));
        add_shortcode('esc_division_schedule', array($this, 'render_division_schedule_shortcode'));
    }

    public static function instance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public function render_admin_notice()
    {
        if (! current_user_can('manage_options')) {
            return;
        }
        ?>
        <div class="notice notice-info is-dismissible">
            <p><?php esc_html_e('Support your local hockey club!', 'esc-gamepitch'); ?></p>
        </div>
        <?php
    }

    public function register_assets()
    {
        wp_register_script(
            'esc-gamepitch-init',
            plugin_dir_url(__FILE__) . 'assets/gamepitch.js',
            array('jquery'),
            '1.1.3',
            true
        );

        wp_register_style(
            'esc-gamepitch-local',
            plugin_dir_url(__FILE__) . 'assets/gamepitch.css',
            array(),
            '1.0.0'
        );
    }

    public function register_block_editor_assets()
    {
        wp_register_script(
            'esc-gamepitch-block-editor',
            plugin_dir_url(__FILE__) . 'assets/block.js',
            array('wp-blocks', 'wp-element', 'wp-editor', 'wp-components', 'wp-i18n', 'wp-block-editor', 'wp-server-side-render'),
            '1.2.6',
            true
        );

        wp_enqueue_script('esc-gamepitch-block-editor');
    }

    public function register_block()
    {
        if (! function_exists('register_block_type')) {
            return;
        }

        $attributes = array(
            'api_key' => array('type' => 'string', 'default' => ''),
            'division_id' => array('type' => 'string', 'default' => ''),
            'divisions' => array('type' => 'string', 'default' => ''),
            'widgets' => array('type' => 'string', 'default' => ''),
            'stats_preset' => array('type' => 'string', 'default' => 'basic'),
            'tabs' => array('type' => 'string', 'default' => ''),
            'game_link' => array('type' => 'string', 'default' => ''),
            'team_id' => array('type' => 'string', 'default' => ''),
            'game_id' => array('type' => 'string', 'default' => ''),
            'mode' => array('type' => 'string', 'default' => 'all'),
            'limit' => array('type' => 'string', 'default' => ''),
            'widget_name' => array('type' => 'string', 'default' => ''),
            'js_modules' => array('type' => 'string', 'default' => ''),
            'css_modules' => array('type' => 'string', 'default' => ''),
            'class' => array('type' => 'string', 'default' => ''),
            'options' => array('type' => 'string', 'default' => '{}'),
            'fallback_message' => array('type' => 'string', 'default' => 'Live game data is currently unavailable.'),
        );

        register_block_type('esc/gamepitch', array(
            'render_callback' => array($this, 'render_block'),
            'attributes' => $attributes,
        ));

        register_block_type('esc/schedule', array(
            'render_callback' => array($this, 'render_block'),
            'attributes' => $attributes,
        ));

        register_block_type('esc/standings', array(
            'render_callback' => array($this, 'render_block'),
            'attributes' => $attributes,
        ));

        register_block_type('esc/game-livebox', array(
            'render_callback' => array($this, 'render_block'),
            'attributes' => $attributes,
        ));

        register_block_type('esc/divisionpicker', array(
            'render_callback' => array($this, 'render_block'),
            'attributes' => $attributes,
        ));

        register_block_type('esc/gameticker', array(
            'render_callback' => array($this, 'render_block'),
            'attributes' => $attributes,
        ));

        register_block_type('esc/gameslider', array(
            'render_callback' => array($this, 'render_block'),
            'attributes' => $attributes,
        ));

        register_block_type('esc/livegames', array(
            'render_callback' => array($this, 'render_block'),
            'attributes' => $attributes,
        ));

        $division_schedule_attributes = array_merge($attributes, array(
            'game_link' => array('type' => 'string', 'default' => ''),
            'divisions' => array('type' => 'string', 'default' => ''),
        ));

        register_block_type('esc/division-schedule', array(
            'render_callback' => array($this, 'render_block'),
            'attributes' => $division_schedule_attributes,
        ));
    }

    public function render_block($attributes, $content = '', $block = null)
    {
        $atts = array();
        if (is_array($attributes)) {
            $atts = $attributes;
        }

        // Gutenberg always sends block attributes, including empty strings.
        // Remove empty overrides so plugin settings are used as defaults.
        foreach (array('api_key', 'division_id', 'team_id') as $default_key) {
            if (! array_key_exists($default_key, $atts)) {
                continue;
            }

            $raw_value = $atts[$default_key];
            if ($raw_value === null) {
                unset($atts[$default_key]);
                continue;
            }

            if (is_string($raw_value) && trim($raw_value) === '') {
                unset($atts[$default_key]);
            }
        }

        $block_name = '';
        if (is_object($block) && isset($block->name)) {
            $block_name = (string) $block->name;
        }

        $is_schedule_block = (
            $block_name === 'esc/schedule'
            || (isset($atts['mode']) && in_array(strtolower((string) $atts['mode']), array('all', 'past', 'future'), true))
            || (isset($atts['limit']) && (string) $atts['limit'] !== '')
            || (isset($atts['widget_name']) && strtolower((string) $atts['widget_name']) === 'hockeydata.los.schedule')
        );

        if ($is_schedule_block) {
            $atts = wp_parse_args($atts, array(
                'sport' => 'icehockey',
                'widget_name' => 'hockeydata.los.Schedule',
                'js_modules' => 'los_schedule&los_configuration_icehockey',
                'css_modules' => 'los_template_default',
            ));
        } elseif ($block_name === 'esc/standings') {
            $atts = wp_parse_args($atts, array(
                'sport' => 'icehockey',
                'widget_name' => 'hockeydata.los.Standings',
                'js_modules' => 'los_standings&los_configuration_icehockey',
                'css_modules' => 'los_template_default',
            ));
        } elseif ($block_name === 'esc/game-livebox') {
            $atts = wp_parse_args($atts, array(
                'widget_name' => 'hockeydata.los.Game.LiveBox',
                'js_modules' => 'los_game_livebox',
                'css_modules' => 'los_game_livebox',
            ));
        } elseif ($block_name === 'esc/divisionpicker') {
            $atts = wp_parse_args($atts, array(
                'widget_name' => 'hockeydata.los.DivisionPicker',
                'stats_preset' => 'basic',
                'js_modules' => 'los_divisionpicker&los_standings&los_schedule&los_game_fullreport&los_teamstats&los_leaders&los_configuration_icehockey',
                'css_modules' => 'los_divisionpicker&los_template_default&los_game_fullreport&los_teamstats&los_leaders',
            ));
        } elseif ($block_name === 'esc/gameticker') {
            $atts = wp_parse_args($atts, array(
                'widget_name' => 'hockeydata.los.GameTicker',
                'js_modules' => 'los_gameticker',
                'css_modules' => 'los_gameticker',
            ));
        } elseif ($block_name === 'esc/gameslider') {
            $atts = wp_parse_args($atts, array(
                'widget_name' => 'hockeydata.los.GameSlider',
                'js_modules' => 'los_gameslider',
                'css_modules' => 'los_gameslider',
            ));
        } elseif ($block_name === 'esc/livegames') {
            $atts = wp_parse_args($atts, array(
                'widget_name' => 'hockeydata.los.LiveGames',
                'js_modules' => 'los_livegames',
                'css_modules' => 'los_livegames',
            ));
        } elseif ($block_name === 'esc/division-schedule') {
            return $this->render_division_schedule_shortcode($atts);
        }

        return $this->render_shortcode($atts);
    }

    public function register_settings()
    {
        register_setting(
            'esc_gamepitch_settings_group',
            self::OPTION_KEY,
            array($this, 'sanitize_settings')
        );

        add_settings_section(
            'esc_gamepitch_main',
            'Default Widget Configuration',
            '__return_false',
            'esc-gamepitch-settings'
        );

        $fields = array(
            'api_key' => 'API Key',
            'division_id' => 'Division ID',
            'division_ids' => 'Division IDs (comma-separated, for Standings)',
            'season_divisions_json' => 'Season Divisions JSON (for DivisionPicker)',
            'default_team_id' => 'Default Team ID (optional)',
            'debug_comments' => 'Debug Comments',
            'widget_name' => 'Widget Class (default: hockeydata.los.Game.LiveBox)',
            'js_modules' => 'JS Modules (ampersand-separated)',
            'css_modules' => 'CSS Modules (ampersand-separated)',
            'default_game_id' => 'Default Game ID (optional)',
        );

        foreach ($fields as $key => $label) {
            add_settings_field(
                $key,
                $label,
                array($this, 'render_settings_field'),
                'esc-gamepitch-settings',
                'esc_gamepitch_main',
                array('key' => $key)
            );
        }
    }

    public function sanitize_settings($input)
    {
        $out = array();
        $current = $this->get_settings();

        $out['api_key'] = isset($input['api_key']) ? sanitize_text_field($input['api_key']) : '';
        $out['division_id'] = isset($input['division_id']) ? intval($input['division_id']) : 0;
        if (isset($input['division_ids']) && $input['division_ids'] !== '') {
            $ids = array_filter(array_map('intval', explode(',', sanitize_text_field($input['division_ids']))));
            $out['division_ids'] = implode(',', $ids);
        } else {
            $out['division_ids'] = '';
        }
        if (isset($input['season_divisions_json'])) {
            $season_raw = wp_kses_post((string) $input['season_divisions_json']);
            $season_raw = trim($season_raw);

            if ($season_raw === '') {
                $out['season_divisions_json'] = '';
            } else {
                $season_decoded = $this->decode_json_attribute($season_raw);
                if (is_array($season_decoded) && ! empty($season_decoded)) {
                    $out['season_divisions_json'] = (string) wp_json_encode($season_decoded);
                } else {
                    $out['season_divisions_json'] = isset($current['season_divisions_json']) ? (string) $current['season_divisions_json'] : '';
                    add_settings_error(
                        self::OPTION_KEY,
                        'season_divisions_json_invalid',
                        __('Season Divisions JSON is invalid. Please use valid JSON (array or grouped object). Previous value was kept.', 'esc-gamepitch'),
                        'error'
                    );
                }
            }
        } else {
            $out['season_divisions_json'] = '';
        }
        $out['default_team_id'] = isset($input['default_team_id']) ? intval($input['default_team_id']) : 0;
        $out['sport'] = 'icehockey';
        $out['debug_comments'] = isset($input['debug_comments']) ? 1 : 0;
        $out['widget_name'] = isset($input['widget_name']) ? sanitize_text_field($input['widget_name']) : 'hockeydata.los.Game.LiveBox';
        $out['js_modules'] = isset($input['js_modules']) ? sanitize_text_field($input['js_modules']) : 'los_game_livebox';
        $out['css_modules'] = isset($input['css_modules']) ? sanitize_text_field($input['css_modules']) : 'los_game_livebox';
        $out['default_game_id'] = isset($input['default_game_id']) ? intval($input['default_game_id']) : 0;

        return $out;
    }

    public function handle_install_template()
    {
        if (! current_user_can('manage_options')) {
            wp_die(esc_html__('You do not have permission to perform this action.', 'esc-gamepitch'));
        }

        check_admin_referer('esc_gamepitch_install_template');

        $theme_dir = get_stylesheet_directory();
        $filename  = 'page-esc-standings-report.php';
        $dest      = $theme_dir . '/' . $filename;

        $redirect_base = admin_url('admin.php?page=esc-gamepitch-settings&tab=settings');

        if (file_exists($dest)) {
            wp_safe_redirect(add_query_arg('esc_tpl', 'exists', $redirect_base));
            exit;
        }

        $content = $this->sample_template_content();

        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
        $written = file_put_contents($dest, $content);

        if ($written === false) {
            wp_safe_redirect(add_query_arg('esc_tpl', 'error', $redirect_base));
            exit;
        }

        wp_safe_redirect(add_query_arg('esc_tpl', 'ok', $redirect_base));
        exit;
    }

    private function sample_template_content()
    {
        return <<<'PHP'
<?php
/**
 * Template Name: ESC Standings Report Flow
 * Description: Query-string based flow from standings to game report and back.
 */

if (! defined('ABSPATH')) {
    exit;
}

get_header();

$view = isset($_GET['view']) ? sanitize_text_field(wp_unslash($_GET['view'])) : '';
$game_id = isset($_GET['game_id']) ? intval($_GET['game_id']) : 0;
$division_id = isset($_GET['division_id']) ? intval($_GET['division_id']) : 13;
$team_id = isset($_GET['team_id']) ? intval($_GET['team_id']) : 27;

$base_url = get_permalink();
$back_link = add_query_arg(
    array(
        'division_id' => $division_id,
        'team_id'     => $team_id,
    ),
    $base_url
);

?>
<div id="primary" class="content-area">
    <main id="main" class="site-main">
        <div class="entry-content">
            <?php if ($view === 'report' && $game_id > 0) : ?>
                <p>
                    <a href="<?php echo esc_url($back_link); ?>">&larr; Back to standings</a>
                </p>
                <?php
                echo do_shortcode('[esc_game_livebox fallback_message="Game report is currently unavailable."]');
                ?>
            <?php else : ?>
                <?php
                echo do_shortcode('[esc_standings fallback_message="Standings are currently unavailable."]');

                $game_link = sprintf(
                    '?view=report&game_id=%%s&division_id=%d&team_id=%d',
                    $division_id,
                    $team_id
                );

                echo do_shortcode(
                    '[esc_division_schedule '
                    . 'game_link="' . esc_attr($game_link) . '" '
                    . 'fallback_message="Schedule is currently unavailable."]'
                );
                ?>
            <?php endif; ?>
        </div>
    </main>
</div>
<?php

get_footer();
PHP;
    }

    public function register_settings_page()
    {
        $this->ensure_parent_menu();

        add_submenu_page(
            'esc-river-rats',
            'ESC GamePitch',
            'ESC GamePitch',
            'manage_options',
            'esc-gamepitch-settings',
            array($this, 'render_settings_page')
        );

        remove_submenu_page('esc-river-rats', 'esc-river-rats');
        remove_submenu_page('options-general.php', 'esc-gamepitch-settings');
    }

    private function ensure_parent_menu()
    {
        global $menu;

        if (isset($menu) && is_array($menu)) {
            foreach ($menu as $item) {
                if (isset($item[2]) && $item[2] === 'esc-river-rats') {
                    return;
                }
            }
        }

        add_menu_page(
            __('ESC River Rats', 'esc-gamepitch'),
            __('ESC River Rats', 'esc-gamepitch'),
            'manage_options',
            'esc-river-rats',
            '__return_null',
            'dashicons-groups',
            26
        );
    }

    public function render_settings_field($args)
    {
        $key = $args['key'];
        $settings = $this->get_settings();
        $value = isset($settings[$key]) ? $settings[$key] : '';

        if ($key === 'debug_comments') {
            ?>
            <label>
                <input
                    type="checkbox"
                    name="<?php echo esc_attr(self::OPTION_KEY); ?>[debug_comments]"
                    value="1"
                    <?php checked(! empty($value)); ?>
                />
                Output masked widget payloads as HTML comments for troubleshooting.
            </label>
            <p class="description">You can still override this per request with <code>?esc_gamepitch_debug=1</code> or per shortcode with <code>debug="1"</code>.</p>
            <?php
            return;
        }

        if ($key === 'season_divisions_json') {
            $example_json = '{"2025/26":[{"divisionId":13,"divisionName":"Grunddurchgang"},{"divisionId":27,"divisionName":"Playoffs"}],"2024/25":[{"divisionId":44,"divisionName":"Grunddurchgang"},{"divisionId":52,"divisionName":"Playoffs"}]}';
            ?>
            <textarea
                name="<?php echo esc_attr(self::OPTION_KEY); ?>[season_divisions_json]"
                class="large-text code"
                rows="6"
            ><?php echo esc_textarea((string) $value); ?></textarea>
            <?php
            echo '<p class="description">'
                . 'Optional JSON for <code>hockeydata.los.DivisionPicker</code>. Supports both array and grouped object format. '
                . 'Use grouped object keys as seasons to select current and previous seasons, e.g. '
                . '<code>{"2025/26":[{"divisionId":13,"divisionName":"Grunddurchgang"}],"2024/25":[{"divisionId":44,"divisionName":"Playoffs"}]}</code>.'
                . '</p>';
            echo '<p class="description"><strong>'
                . esc_html__('Copy/Paste example:', 'esc-gamepitch')
                . '</strong></p>';
            echo '<textarea class="large-text code" rows="4" readonly>' . esc_textarea($example_json) . '</textarea>';
            return;
        }

        ?>
        <input
            type="text"
            name="<?php echo esc_attr(self::OPTION_KEY); ?>[<?php echo esc_attr($key); ?>]"
            value="<?php echo esc_attr($value); ?>"
            class="regular-text"
        />
        <?php
        if ($key === 'division_id' || $key === 'default_team_id') {
            echo '<p class="description">'
                . 'Find your Division ID and Team ID using the '
                . '<a href="https://apidocs.hockeydata.net/division-finder/" target="_blank" rel="noopener">HockeyData Division Finder</a>.'
                . '</p>';
        }
        if ($key === 'division_ids') {
            echo '<p class="description">'
                . 'Comma-separated list of Division IDs used as the <code>divisions</code> array for the Standings widget. '
                . 'Example: <code>13,14,15</code>. Leave empty to use the single Division ID above.'
                . '</p>';
        }
        if ($key === 'widget_name') {
            echo '<p class="description">'
                . 'Must be a valid widget class from the '
                . '<a href="https://apidocs.hockeydata.net/javascript-api/" target="_blank" rel="noopener">HockeyData JavaScript API</a>. '
                . 'E.g. <code>hockeydata.los.Game.LiveBox</code>, <code>hockeydata.los.GameSlider</code>, '
                . '<code>hockeydata.los.Schedule</code>, <code>hockeydata.los.Standings</code>.'
                . '</p>';
        }
    }

    public function render_settings_page()
    {
        $active_tab = (isset($_GET['tab']) && $_GET['tab'] === 'help') ? 'help' : 'settings';
        $settings_url = esc_url(admin_url('admin.php?page=esc-gamepitch-settings&tab=settings'));
        $help_url     = esc_url(admin_url('admin.php?page=esc-gamepitch-settings&tab=help'));
        ?>
        <div class="wrap">
            <h1>ESC GamePitch</h1>
            <p class="description">
                <?php
                printf(
                    esc_html__('Version %s', 'esc-gamepitch'),
                    esc_html(self::VERSION)
                );
                ?>
            </p>
            <nav class="nav-tab-wrapper" style="margin-bottom:0">
                <a href="<?php echo $settings_url; ?>" class="nav-tab <?php echo $active_tab === 'settings' ? 'nav-tab-active' : ''; ?>">
                    <?php esc_html_e('Settings', 'esc-gamepitch'); ?>
                </a>
                <a href="<?php echo $help_url; ?>" class="nav-tab <?php echo $active_tab === 'help' ? 'nav-tab-active' : ''; ?>">
                    <?php esc_html_e('Help', 'esc-gamepitch'); ?>
                </a>
            </nav>
            <div class="tab-content" style="padding-top:1.5em">
            <?php if ($active_tab === 'help') : ?>
                <?php $this->render_help_tab(); ?>
            <?php else : ?>
                <?php
                $esc_tpl = isset($_GET['esc_tpl']) ? sanitize_text_field(wp_unslash($_GET['esc_tpl'])) : '';
                if ($esc_tpl === 'ok') :
                ?>
                    <div class="notice notice-success is-dismissible"><p><?php esc_html_e('Template installed successfully.', 'esc-gamepitch'); ?></p></div>
                <?php elseif ($esc_tpl === 'exists') : ?>
                    <div class="notice notice-warning is-dismissible"><p><?php esc_html_e('Template already exists in the active theme — no changes made.', 'esc-gamepitch'); ?></p></div>
                <?php elseif ($esc_tpl === 'error') : ?>
                    <div class="notice notice-error is-dismissible"><p><?php esc_html_e('Template could not be written. Check theme folder permissions.', 'esc-gamepitch'); ?></p></div>
                <?php endif; ?>
                <p>Configure default values used by the shortcode <code>[esc_gamepitch]</code>.</p>
                <form action="options.php" method="post">
                    <?php
                    settings_fields('esc_gamepitch_settings_group');
                    do_settings_sections('esc-gamepitch-settings');
                    submit_button();
                    ?>
                </form>
                <h2>Shortcode Example</h2>
                <p><code>[esc_gamepitch game_id="12345"]</code></p>
                <h2><?php esc_html_e('Schedule Modes', 'esc-gamepitch'); ?></h2>
                <p><?php esc_html_e('Use the mode attribute on ESC Schedule to filter by time window.', 'esc-gamepitch'); ?></p>
                <p>
                    <code>[esc_schedule mode="all"]</code><br />
                    <code>[esc_schedule mode="past"]</code><br />
                    <code>[esc_schedule mode="future"]</code><br />
                    <code>[esc_schedule limit="8"]</code>
                </p>
                <p class="description">
                    <?php esc_html_e('all: all games (default) · past: only games before today · future: today and upcoming games · limit: max number of rows to display.', 'esc-gamepitch'); ?>
                </p>
                <hr />
                <h2><?php esc_html_e('Sample Page Template', 'esc-gamepitch'); ?></h2>
                <?php
                $theme_dir  = get_stylesheet_directory();
                $theme_name = wp_get_theme()->get('Name');
                $filename   = 'page-esc-standings-report.php';
                $dest       = $theme_dir . '/' . $filename;
                $installed  = file_exists($dest);
                ?>
                <p>
                    <?php
                    printf(
                        /* translators: 1: template filename, 2: theme name */
                        esc_html__('Installs %1$s into the active theme (%2$s). Assign the template "ESC Standings Report Flow" to any page to get a standings + game-report flow driven entirely by query string.', 'esc-gamepitch'),
                        '<code>' . esc_html($filename) . '</code>',
                        '<strong>' . esc_html($theme_name) . '</strong>'
                    );
                    ?>
                </p>
                <?php if ($installed) : ?>
                    <p><span class="dashicons dashicons-yes" style="color:#46b450"></span> <?php esc_html_e('Template is already installed.', 'esc-gamepitch'); ?></p>
                <?php endif; ?>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                    <input type="hidden" name="action" value="esc_gamepitch_install_template" />
                    <?php wp_nonce_field('esc_gamepitch_install_template'); ?>
                    <?php submit_button(
                        $installed ? __('Reinstall Template', 'esc-gamepitch') : __('Install Sample Template', 'esc-gamepitch'),
                        $installed ? 'secondary' : 'primary',
                        'submit',
                        false
                    ); ?>
                </form>
            <?php endif; ?>
            </div>
        </div>
        <?php
    }

    private function render_help_tab()
    {
        $readme_path = plugin_dir_path(__FILE__) . 'README.md';
        if (! file_exists($readme_path)) {
            echo '<p>README.md not found.</p>';
            return;
        }
        $content = file_get_contents($readme_path);
        if ($content === false) {
            echo '<p>Could not read README.md.</p>';
            return;
        }
        $allowed = wp_kses_allowed_html('post');
        $allowed['pre']   = array('style' => array());
        $allowed['code']  = array();
        $allowed['hr']    = array();
        $allowed['table'] = array();
        $allowed['thead'] = array();
        $allowed['tbody'] = array();
        $allowed['tr']    = array();
        $allowed['th']    = array();
        $allowed['td']    = array();
        echo '<div style="max-width:860px; background:#fff; border:1px solid #dcdcde; padding:16px 18px; border-radius:8px; box-sizing:border-box;">';
        echo '<style>.esc-gamepitch-help h1,.esc-gamepitch-help h2,.esc-gamepitch-help h3,.esc-gamepitch-help h4{margin-top:1.5em;margin-bottom:.5em}.esc-gamepitch-help p,.esc-gamepitch-help li{line-height:1.6}.esc-gamepitch-help code{background:#f6f7f7;padding:2px 5px;border-radius:3px}.esc-gamepitch-help pre{margin:1em 0;padding:12px 14px;border-radius:6px}.esc-gamepitch-help table{border-collapse:collapse;width:100%;margin:1em 0}.esc-gamepitch-help th,.esc-gamepitch-help td{border:1px solid #dcdcde;padding:8px 10px;text-align:left;vertical-align:top}.esc-gamepitch-help ul{padding-left:1.5em;margin:1em 0}.esc-gamepitch-help hr{border:none;border-top:1px solid #dcdcde;margin:1.5em 0}</style>';
        echo '<div class="esc-gamepitch-help">';
        echo wp_kses($this->markdown_to_html($content), $allowed);
        echo '</div>';
        echo '</div>';
    }

    private function markdown_to_html($text)
    {
        $lines = explode("\n", str_replace("\r\n", "\n", $text));
        $out   = '';
        $i     = 0;
        $count = count($lines);

        while ($i < $count) {
            $line = $lines[$i];

            if (preg_match('/^```/', $line)) {
                $in_code = true;
                $code_buf = '';
                $i++;
                while ($i < $count && ! preg_match('/^```/', $lines[$i])) {
                    $code_buf .= $lines[$i] . "\n";
                    $i++;
                }
                $out .= '<pre style="background:#f6f7f7;padding:12px 16px;overflow:auto"><code>'
                    . esc_html(rtrim($code_buf, "\n")) . "</code></pre>\n";
                $i++;
                continue;
            }

            if (preg_match('/^(#{1,4}) (.+)/', $line, $m)) {
                $lv   = strlen($m[1]);
                $out .= "<h{$lv}>" . $this->md_inline($m[2]) . "</h{$lv}>\n";
                $i++;
                continue;
            }

            if (preg_match('/^-{3,}$/', trim($line))) {
                $out .= "<hr />\n";
                $i++;
                continue;
            }

            if (preg_match('/^\s*[-*] (.+)/', $line, $m)) {
                $out .= "<ul>\n";
                while ($i < $count && preg_match('/^\s*[-*] (.+)/', $lines[$i], $m2)) {
                    $out .= '<li>' . $this->md_inline($m2[1]) . "</li>\n";
                    $i++;
                }
                $out .= "</ul>\n";
                continue;
            }

            if (preg_match('/^\|.*\|$/', trim($line)) && $i + 1 < $count && preg_match('/^\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+\|?$/', trim($lines[$i + 1]))) {
                $out .= "<table style=\"width:100%;border-collapse:collapse;margin:1em 0;\"><thead><tr>";
                $headers = array_map('trim', explode('|', trim($line, '|')));
                foreach ($headers as $header) {
                    $out .= '<th style="text-align:left;border:1px solid #dcdcde;padding:8px 10px;">' . $this->md_inline($header) . '</th>';
                }
                $out .= "</tr></thead><tbody>";
                $i += 2;
                while ($i < $count && preg_match('/^\|.*\|$/', trim($lines[$i]))) {
                    $cells = array_map('trim', explode('|', trim($lines[$i], '|')));
                    $out .= '<tr>';
                    foreach ($cells as $cell) {
                        $out .= '<td style="border:1px solid #dcdcde;padding:8px 10px;">' . $this->md_inline($cell) . '</td>';
                    }
                    $out .= '</tr>';
                    $i++;
                }
                $out .= "</tbody></table>\n";
                continue;
            }

            if (trim($line) === '') {
                $i++;
                continue;
            }

            $out .= '<p>' . $this->md_inline($line) . "</p>\n";
            $i++;
        }

        return $out;
    }

    private function md_inline($text)
    {
        // Split on inline code spans — process their interiors separately.
        $parts  = preg_split('/(`[^`]+`)/', $text, -1, PREG_SPLIT_DELIM_CAPTURE);
        $result = '';
        foreach ($parts as $part) {
            if ($part !== '' && $part[0] === '`') {
                $result .= '<code>' . esc_html(substr($part, 1, -1)) . '</code>';
                continue;
            }
            // Escape HTML special chars first; **, [ ] ( ) are unaffected.
            $part = esc_html($part);
            // Bold
            $part = preg_replace('/\*\*(.+?)\*\*/', '<strong>$1</strong>', $part);
            // Links
            $part = preg_replace_callback(
                '/\[([^\]]+)\]\((https?:[^)]+)\)/',
                function ($m) {
                    return '<a href="' . esc_url($m[2]) . '" target="_blank" rel="noopener">' . $m[1] . '</a>';
                },
                $part
            );
            $result .= $part;
        }
        return $result;
    }

    public function render_shortcode($atts)
    {
        $settings = $this->get_settings();

        $defaults = array(
            'api_key' => $settings['api_key'],
            'division_id' => $settings['division_id'],
            'division_ids' => isset($settings['division_ids']) ? $settings['division_ids'] : '',
            'divisions' => isset($settings['season_divisions_json']) ? $settings['season_divisions_json'] : '',
            'widgets' => '',
            'stats_preset' => 'basic',
            'tabs' => '',
            'game_link' => '',
            'sport' => 'icehockey',
            'team_id' => $settings['default_team_id'],
            'widget_name' => $settings['widget_name'],
            'js_modules' => $settings['js_modules'],
            'css_modules' => $settings['css_modules'],
            'game_id' => $settings['default_game_id'],
            'options' => '{}',
            'class' => '',
            'debug' => '0',
            'current_only' => '0',
            'mode' => 'all',
            'limit' => '',
            'fallback_message' => 'Live game data is currently unavailable.',
        );

        $atts = shortcode_atts($defaults, $atts, 'esc_gamepitch');
        $atts = $this->apply_query_id_overrides($atts);

        $api_key = sanitize_text_field((string) $atts['api_key']);
        $division_id = intval($atts['division_id']);
        $sport = 'icehockey';
        $team_id = intval($atts['team_id']);
        $widget_name = sanitize_text_field((string) $atts['widget_name']);
        $game_id = isset($atts['game_id']) ? trim((string) $atts['game_id']) : '';
        $js_modules = $this->sanitize_modules((string) $atts['js_modules']);
        $css_modules = $this->sanitize_modules((string) $atts['css_modules']);
        $debug_enabled = $this->is_debug_enabled($atts, $settings);
        $current_only = isset($atts['current_only']) && in_array(strtolower((string) $atts['current_only']), array('1', 'true', 'yes', 'on'), true);
        $schedule_mode = isset($atts['mode']) ? strtolower(sanitize_key((string) $atts['mode'])) : 'all';
        if (! in_array($schedule_mode, array('all', 'past', 'future'), true)) {
            $schedule_mode = 'all';
        }
        $schedule_limit = isset($atts['limit']) ? intval($atts['limit']) : 0;
        if ($schedule_limit < 0) {
            $schedule_limit = 0;
        }

        if ($schedule_mode !== 'all' || $schedule_limit > 0 || array_key_exists('mode', $atts) || array_key_exists('limit', $atts)) {
            $widget_name = 'hockeydata.los.Schedule';
        }

        $fallback_message = sanitize_text_field((string) $atts['fallback_message']);

        // DivisionPicker, GameSlider and LiveGames can resolve divisionId from the URL at runtime.
        $division_optional = in_array($widget_name, array(
            'hockeydata.los.DivisionPicker',
            'hockeydata.los.GameSlider',
            'hockeydata.los.LiveGames',
        ), true);

        if ($api_key === '' || (! $division_optional && $division_id <= 0) || $sport === '') {
            return '<p class="esc-gamepitch-error">ESC GamePitch: missing api_key, division_id or sport.</p>';
        }

        if ($widget_name === '') {
            $widget_name = 'hockeydata.los.Game.LiveBox';
        }

        $custom_options = $this->decode_json_attribute(isset($atts['options']) ? (string) $atts['options'] : '{}');

        $base_options = array(
            'apiKey' => $api_key,
            'sport' => $sport,
        );

        if ($division_id > 0) {
            $base_options['divisionId'] = $division_id;
        }

        $widget_options = array_merge($base_options, $custom_options);

        if ($game_id !== '' && strpos($widget_name, 'hockeydata.los.Game.') === 0) {
            $widget_options['gameId'] = $game_id;
        }

        if ($team_id > 0) {
            $widget_options['teamId'] = $team_id;
        }

        // Schedule widgets are filtered in the client after the widget paint cycle.
        // Passing a raw "limit" into the underlying HockeyData widget can conflict
        // with mode-based futureOnly/maxDate filtering when both are used.

        // The Standings widget requires a 'divisions' array. Build it from the
        // comma-separated division_ids setting, falling back to the single division_id.
        if (
            $widget_name === 'hockeydata.los.Standings'
            && ! isset($widget_options['divisions'])
        ) {
            $raw_ids = isset($atts['division_ids']) ? (string) $atts['division_ids'] : '';
            if ($raw_ids !== '') {
                $id_list = array_filter(array_map('intval', explode(',', $raw_ids)));
                if (! empty($id_list)) {
                    $widget_options['divisions'] = array_values(
                        array_map(function ($id) { return array('divisionId' => $id); }, $id_list)
                    );
                }
            } elseif ($division_id > 0) {
                $widget_options['divisions'] = array(array('divisionId' => $division_id));
            }
        }

        if ($widget_name === 'hockeydata.los.DivisionPicker') {
            $divisions_json = isset($atts['divisions']) ? (string) $atts['divisions'] : '';
            if ($divisions_json !== '' && ! isset($widget_options['divisions'])) {
                $decoded_divisions = $this->decode_json_attribute($divisions_json);
                if (is_array($decoded_divisions)) {
                    $widget_options['divisions'] = $decoded_divisions;
                }
            }

            $widgets_json = isset($atts['widgets']) ? (string) $atts['widgets'] : '';
            if ($widgets_json !== '' && ! isset($widget_options['widgets'])) {
                $decoded_widgets = $this->decode_json_attribute($widgets_json);
                if (is_array($decoded_widgets)) {
                    $widget_options['widgets'] = $decoded_widgets;
                }
            }

            if (isset($atts['tabs']) && $atts['tabs'] !== '' && ! isset($widget_options['tabs'])) {
                $widget_options['tabs'] = in_array(strtolower((string) $atts['tabs']), array('1', 'true', 'yes', 'on'), true);
            }

            if (! isset($widget_options['widget']) && ! isset($widget_options['widgets'])) {
                $stats_preset = isset($atts['stats_preset']) ? sanitize_key((string) $atts['stats_preset']) : 'basic';
                $schedule_widget_options = array();
                if ($team_id > 0) {
                    $schedule_widget_options['teamId'] = $team_id;
                }

                $game_link = isset($atts['game_link']) ? $this->normalize_query_game_link_pattern(sanitize_text_field((string) $atts['game_link'])) : '';
                if ($game_link === '') {
                    $game_link = '?game_id=%s&division_id=%s';
                }
                $schedule_widget_options['rowLink'] = $game_link;

                $widget_options['tabs'] = true;
                $default_widgets = array(
                    array(
                        'title' => 'Standings',
                        'widget' => 'hockeydata.los.Standings',
                        'widgetOptions' => array('columnSet' => 'long'),
                    ),
                    array(
                        'title' => 'Schedule',
                        'widget' => 'hockeydata.los.Schedule',
                        'widgetOptions' => $schedule_widget_options,
                    ),
                );

                $selected_game_id = '';
                $game_id_url_parameter = 'game_id';
                if (isset($_GET['game_id'])) {
                    $selected_game_data = $this->extract_game_query_data(wp_unslash($_GET['game_id']));
                    $selected_game_id = $selected_game_data['game_id'];
                    $game_id_url_parameter = 'game_id';
                } elseif (isset($_GET['gameId'])) {
                    $selected_game_data = $this->extract_game_query_data(wp_unslash($_GET['gameId']));
                    $selected_game_id = $selected_game_data['game_id'];
                    $game_id_url_parameter = 'gameId';
                }

                if ($selected_game_id !== '') {
                    array_unshift($default_widgets, array(
                        'title' => 'Game Report',
                        'widget' => 'hockeydata.los.Game.FullReport',
                        'widgetOptions' => array(
                            'gameIdUrlParameter' => $game_id_url_parameter,
                        ),
                    ));
                }

                if ($stats_preset === 'extended') {
                    $default_widgets[] = array(
                        'title' => 'Team Stats',
                        'widget' => 'hockeydata.los.TeamStats',
                        'widgetOptions' => array(),
                    );
                    $default_widgets[] = array(
                        'title' => 'Leaders',
                        'widget' => 'hockeydata.los.Leaders',
                        'widgetOptions' => array(),
                    );
                }

                $widget_options['widgets'] = $default_widgets;
            }
        }

        $this->enqueue_hockeydata_assets($js_modules, $css_modules);

        wp_enqueue_script('esc-gamepitch-init');
        wp_enqueue_style('esc-gamepitch-local');
        wp_localize_script('esc-gamepitch-init', 'escGamePitchConfig', array(
            'debugAllowed' => current_user_can('manage_options') ? 1 : 0,
        ));

        $dom_id = 'esc-gamepitch-' . wp_rand(1000, 999999);
        $class_name = sanitize_html_class((string) $atts['class']);

        if ($widget_name === 'hockeydata.los.Schedule') {
            // HockeyData schedule widgets expect the actual filter options instead of
            // only a generic mode label. Map the shortcode mode into widget settings
            // before the payload is serialized, otherwise the earlier payload copy would
            // still contain the old, unfiltered widgetOptions.
            if ($schedule_mode === 'future') {
                $widget_options['futureOnly'] = true;
            } elseif ($schedule_mode === 'past') {
                $widget_options['maxDate'] = gmdate('Y-m-d', current_time('timestamp'));
            }
        }

        $payload = array(
            'domId' => $dom_id,
            'widgetName' => $widget_name,
            'widgetOptions' => $widget_options,
            'fallbackMessage' => $fallback_message,
            'debugAllowed' => current_user_can('manage_options'),
        );

        if ($widget_name === 'hockeydata.los.GameTicker' && $current_only) {
            $payload['onlyWhenCurrent'] = true;
        }

        if ($widget_name === 'hockeydata.los.Schedule') {
            $payload['scheduleMode'] = $schedule_mode;
            $payload['scheduleLimit'] = $schedule_limit > 0 ? $schedule_limit : 0;
        }

        $json_payload = wp_json_encode($payload);
        if ($json_payload === false) {
            return '<p class="esc-gamepitch-error">ESC GamePitch: could not encode widget options.</p>';
        }

        ob_start();
        if ($debug_enabled) {
            echo "\n<!-- ESC GamePitch Debug: " . esc_html(wp_json_encode($this->build_debug_payload($payload, $js_modules, $css_modules))) . " -->\n";
        }
        ?>
        <div
            id="<?php echo esc_attr($dom_id); ?>"
            class="esc-gamepitch-widget <?php echo esc_attr($class_name); ?>"
            data-esc-gamepitch="<?php echo esc_attr($json_payload); ?>"
        ></div>
        <?php

        return (string) ob_get_clean();
    }

    public function render_game_livebox_shortcode($atts)
    {
        return $this->render_preset_shortcode($atts, array(
            'widget_name' => 'hockeydata.los.Game.LiveBox',
            'js_modules' => 'los_game_livebox',
            'css_modules' => 'los_game_livebox',
        ));
    }

    public function render_divisionpicker_shortcode($atts)
    {
        return $this->render_preset_shortcode($atts, array(
            'widget_name' => 'hockeydata.los.DivisionPicker',
            'stats_preset' => 'basic',
            'js_modules' => 'los_divisionpicker&los_standings&los_schedule&los_game_fullreport&los_teamstats&los_leaders&los_configuration_icehockey',
            'css_modules' => 'los_divisionpicker&los_template_default&los_game_fullreport&los_teamstats&los_leaders',
        ));
    }

    public function render_gameticker_shortcode($atts)
    {
        return $this->render_preset_shortcode($atts, array(
            'widget_name' => 'hockeydata.los.GameTicker',
            'js_modules' => 'los_gameticker',
            'css_modules' => 'los_gameticker',
        ));
    }

    public function render_gameticker_current_shortcode($atts)
    {
        return $this->render_preset_shortcode($atts, array(
            'widget_name' => 'hockeydata.los.GameTicker',
            'current_only' => '1',
            'js_modules' => 'los_gameticker',
            'css_modules' => 'los_gameticker',
        ));
    }

    public function render_gameslider_shortcode($atts)
    {
        return $this->render_preset_shortcode($atts, array(
            'widget_name' => 'hockeydata.los.GameSlider',
            'js_modules' => 'los_gameslider',
            'css_modules' => 'los_gameslider',
        ));
    }

    public function render_livegames_shortcode($atts)
    {
        return $this->render_preset_shortcode($atts, array(
            'widget_name' => 'hockeydata.los.LiveGames',
            'js_modules' => 'los_livegames',
            'css_modules' => 'los_livegames',
        ));
    }

    /**
     * Composite shortcode: DivisionPicker + Schedule + optional game-report links.
     *
     * [esc_division_schedule]
      * [esc_division_schedule game_link="?game_id=%s" team_id="27"]
     * [esc_division_schedule divisions='[{"divisionId":13,"divisionName":"Grunddurchgang"},{"divisionId":27,"divisionName":"Playoffs"}]']
     */
    public function render_division_schedule_shortcode($atts)
    {
        $settings = $this->get_settings();

        $defaults = array(
            'api_key'          => $settings['api_key'],
            'division_id'      => $settings['division_id'],
            'team_id'          => $settings['default_team_id'],
            'game_link'        => '',
            'limit'            => '',
            'divisions'        => '',
            'class'            => '',
            'debug'            => '0',
            'fallback_message' => 'Schedule is currently unavailable.',
        );

        $atts = shortcode_atts($defaults, $atts, 'esc_division_schedule');
        $atts = $this->apply_query_id_overrides($atts);

        $api_key          = sanitize_text_field((string) $atts['api_key']);
        $division_id      = intval($atts['division_id']);
        $team_id          = intval($atts['team_id']);
        $game_link        = $this->normalize_query_game_link_pattern(sanitize_text_field((string) $atts['game_link']));
        $schedule_limit   = isset($atts['limit']) ? intval($atts['limit']) : 0;
        $debug_enabled    = $this->is_debug_enabled($atts, $settings);
        $fallback_message = sanitize_text_field((string) $atts['fallback_message']);

        if ($api_key === '') {
            return '<p class="esc-gamepitch-error">ESC GamePitch: missing api_key.</p>';
        }

        // Build inner Schedule widget options.
        $inner_options = array();
        if ($team_id > 0) {
            $inner_options['teamId'] = $team_id;
        }
        if ($game_link !== '') {
            $inner_options['gameLink'] = $game_link;
        }
        if ($schedule_limit > 0) {
            $inner_options['limit'] = $schedule_limit;
        }

        // Build the DivisionPicker widget options.
        $widget_options = array(
            'apiKey'  => $api_key,
            'sport'   => 'icehockey',
            'widget'  => 'hockeydata.los.Schedule',
        );

        if ($division_id > 0) {
            $widget_options['divisionId'] = $division_id;
        }

        if (! empty($inner_options)) {
            $widget_options['widgetOptions'] = $inner_options;
        }

        if ($atts['divisions'] !== '') {
            $divisions_decoded = $this->decode_json_attribute((string) $atts['divisions']);
            if (is_array($divisions_decoded)) {
                $widget_options['divisions'] = $divisions_decoded;
            }
        }

        $js_modules  = 'los_divisionpicker&los_schedule&los_configuration_icehockey';
        $css_modules = 'los_divisionpicker&los_template_default';

        $this->enqueue_hockeydata_assets($js_modules, $css_modules);
        wp_enqueue_script('esc-gamepitch-init');
        wp_enqueue_style('esc-gamepitch-local');
        wp_localize_script('esc-gamepitch-init', 'escGamePitchConfig', array(
            'debugAllowed' => current_user_can('manage_options') ? 1 : 0,
        ));

        $dom_id     = 'esc-gamepitch-' . wp_rand(1000, 999999);
        $class_name = sanitize_html_class((string) $atts['class']);

        $payload = array(
            'domId'           => $dom_id,
            'widgetName'      => 'hockeydata.los.DivisionPicker',
            'widgetOptions'   => $widget_options,
            'fallbackMessage' => $fallback_message,
            'debugAllowed'    => current_user_can('manage_options'),
        );

        $json_payload = wp_json_encode($payload);
        if ($json_payload === false) {
            return '<p class="esc-gamepitch-error">ESC GamePitch: could not encode widget options.</p>';
        }

        ob_start();
        if ($debug_enabled) {
            echo "\n<!-- ESC GamePitch Debug: " . esc_html(wp_json_encode($this->build_debug_payload($payload, $js_modules, $css_modules))) . " -->\n";
        }
        ?>
        <div
            id="<?php echo esc_attr($dom_id); ?>"
            class="esc-gamepitch-widget <?php echo esc_attr($class_name); ?>"
            data-esc-gamepitch="<?php echo esc_attr($json_payload); ?>"
        ></div>
        <?php

        return (string) ob_get_clean();
    }

    public function render_schedule_shortcode($atts)
    {
        return $this->render_preset_shortcode($atts, array(
            'sport' => 'icehockey',
            'widget_name' => 'hockeydata.los.Schedule',
            'mode' => 'all',
            'limit' => '',
            'js_modules' => 'los_schedule&los_configuration_icehockey',
            'css_modules' => 'los_template_default',
        ));
    }

    public function render_standings_shortcode($atts)
    {
        return $this->render_preset_shortcode($atts, array(
            'sport' => 'icehockey',
            'widget_name' => 'hockeydata.los.Standings',
            'js_modules' => 'los_standings&los_configuration_icehockey',
            'css_modules' => 'los_template_default',
        ));
    }

    private function render_preset_shortcode($atts, $preset)
    {
        if (! is_array($atts)) {
            $atts = array();
        }

        return $this->render_shortcode(wp_parse_args($atts, $preset));
    }

    private function enqueue_hockeydata_assets($js_modules, $css_modules)
    {
        $js_handle = 'esc-gamepitch-api-' . md5($js_modules);
        $css_handle = 'esc-gamepitch-api-css-' . md5($css_modules);

        if (! wp_script_is($js_handle, 'registered')) {
            wp_register_script(
                $js_handle,
                $this->build_hockeydata_url('https://api.hockeydata.net/js/', $js_modules),
                array('jquery'),
                null,
                true
            );
        }

        if (! wp_style_is($css_handle, 'registered')) {
            wp_register_style(
                $css_handle,
                $this->build_hockeydata_url('https://api.hockeydata.net/css/', $css_modules),
                array(),
                null
            );
        }

        wp_enqueue_script($js_handle);
        wp_enqueue_style($css_handle);
    }

    private function build_hockeydata_url($base, $modules)
    {
        $parts = array_filter(array_map('trim', explode('&', $modules)));
        $encoded = array();

        foreach ($parts as $part) {
            if ($part === '') {
                continue;
            }
            $encoded[] = rawurlencode($part);
        }

        $query = implode('&', $encoded);
        if ($query === '') {
            return $base;
        }

        return $base . '?' . $query;
    }

    private function sanitize_modules($modules)
    {
        $parts = array_filter(array_map('trim', explode('&', $modules)));
        $clean = array();

        foreach ($parts as $part) {
            $clean[] = preg_replace('/[^a-z0-9_\-]/i', '', $part);
        }

        return implode('&', array_filter($clean));
    }

    private function decode_json_attribute($value)
    {
        if (! is_string($value)) {
            return array();
        }

        $raw = trim($value);
        if ($raw === '') {
            return array();
        }

        $decoded = json_decode($raw, true);
        if (is_array($decoded)) {
            return $decoded;
        }

        // Normalize typographic quotes often introduced by copy/paste from rich text editors.
        $normalized = strtr($raw, array(
            '“' => '"',
            '”' => '"',
            '„' => '"',
            '‟' => '"',
            '’' => "'",
            '‘' => "'",
            '‚' => "'",
        ));

        // Some editors wrap JSON in single quotes; strip one outer pair.
        if (strlen($normalized) >= 2 && $normalized[0] === "'" && $normalized[strlen($normalized) - 1] === "'") {
            $normalized = substr($normalized, 1, -1);
        }

        $decoded = json_decode($normalized, true);
        if (is_array($decoded)) {
            return $decoded;
        }

        return array();
    }

    private function apply_query_id_overrides($atts)
    {
        $id_keys = array('division_id', 'team_id');

        foreach ($id_keys as $key) {
            if (! isset($_GET[$key])) {
                continue;
            }

            $raw_value = wp_unslash($_GET[$key]);
            if ($raw_value === '') {
                continue;
            }

            $atts[$key] = intval(sanitize_text_field((string) $raw_value));
        }

        if (isset($_GET['game_id'])) {
            $game_data = $this->extract_game_query_data(wp_unslash($_GET['game_id']));
            if ($game_data['game_id'] !== '') {
                $atts['game_id'] = $game_data['game_id'];
            }

            // Some integrations pass "game_id=<gameId>,<divisionId>".
            if ($game_data['division_id'] > 0 && ! isset($_GET['division_id'])) {
                $atts['division_id'] = $game_data['division_id'];
            }
        }

        // Accept camelCase aliases from custom links.
        if (isset($_GET['gameId']) && ! isset($_GET['game_id'])) {
            $game_data = $this->extract_game_query_data(wp_unslash($_GET['gameId']));
            if ($game_data['game_id'] !== '') {
                $atts['game_id'] = $game_data['game_id'];
            }

            if ($game_data['division_id'] > 0 && ! isset($_GET['division_id'])) {
                $atts['division_id'] = $game_data['division_id'];
            }
        }

        return $atts;
    }

    private function extract_game_query_data($raw_value)
    {
        $raw = sanitize_text_field((string) $raw_value);
        $raw = trim($raw);

        if ($raw === '') {
            return array(
                'game_id' => '',
                'division_id' => 0,
            );
        }

        $parts = array_map('trim', explode(',', $raw));
        $game_id = isset($parts[0]) ? $parts[0] : '';
        $division_id = 0;

        if (isset($parts[1]) && $parts[1] !== '' && ctype_digit($parts[1])) {
            $division_id = intval($parts[1]);
        }

        return array(
            'game_id' => $game_id,
            'division_id' => $division_id,
        );
    }

    private function normalize_query_game_link_pattern($game_link)
    {
        $game_link = trim((string) $game_link);

        if ($game_link === '') {
            return '?game_id=%s';
        }

        if (strpos($game_link, 'game_id=') !== false) {
            if (strpos($game_link, '%s') === false) {
                return preg_replace('/(game_id=)[^&#]*/', '$1%s', $game_link, 1);
            }
            return $game_link;
        }

        if (strpos($game_link, '%s') !== false) {
            return '?game_id=%s';
        }

        return $game_link . (strpos($game_link, '?') === false ? '?' : '&') . 'game_id=%s';
    }

    private function is_debug_enabled($atts, $settings)
    {
        if (! current_user_can('manage_options')) {
            return false;
        }

        if (isset($_GET['esc_gamepitch_debug']) && $_GET['esc_gamepitch_debug'] === '1') {
            return true;
        }

        if (! empty($atts['debug']) && $atts['debug'] !== '0') {
            return true;
        }

        return ! empty($settings['debug_comments']);
    }

    private function build_debug_payload($payload, $js_modules, $css_modules)
    {
        $debug_payload = $payload;

        if (isset($debug_payload['widgetOptions']['apiKey'])) {
            $debug_payload['widgetOptions']['apiKey'] = $this->mask_api_key((string) $debug_payload['widgetOptions']['apiKey']);
        }

        $debug_payload['jsModules'] = $js_modules;
        $debug_payload['cssModules'] = $css_modules;

        return $debug_payload;
    }

    private function mask_api_key($api_key)
    {
        $length = strlen($api_key);
        if ($length <= 8) {
            return str_repeat('*', $length);
        }

        return substr($api_key, 0, 4) . str_repeat('*', $length - 8) . substr($api_key, -4);
    }

    private function get_settings()
    {
        $defaults = array(
            'api_key' => '',
            'division_id' => 0,
            'division_ids' => '',
            'season_divisions_json' => '',
            'default_team_id' => 0,
            'sport' => 'icehockey',
            'debug_comments' => 0,
            'widget_name' => 'hockeydata.los.Game.LiveBox',
            'js_modules' => 'los_game_livebox',
            'css_modules' => 'los_game_livebox',
            'default_game_id' => 0,
        );

        $settings = get_option(self::OPTION_KEY, array());
        if (! is_array($settings)) {
            $settings = array();
        }

        return wp_parse_args($settings, $defaults);
    }
}

ESC_GamePitch_Plugin::instance();
